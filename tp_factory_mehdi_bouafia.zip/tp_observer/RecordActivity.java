/**
 * Main class for illustrating observers in action
 */
public class RecordActivity {

	public static void main(String[] args) {
		Terminal term = new Terminal();
		term.setVisible(true);
		term.addLogger(new LogFrameFactory());
		term.addLogger(new FileLoggerFactory());
		term.addLogger(new ConsoleLoggerFactory());
	}
}

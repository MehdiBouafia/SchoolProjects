
/**
 * Logs contents of the Terminal to standard output
 */
public class ConsoleLogger implements Logger {

	@Override
	public void update(char msg) {
		System.out.println(msg);
	}
	
}

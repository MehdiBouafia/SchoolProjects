
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Terminal extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel consolePanel;
	private JTextArea commandTA;
	private JScrollPane jsp;
	
	private ArrayList<LogObservators> observators = new ArrayList<LogObservators>();
	
	public void attach(LogObservators o) {
		observators.add(o);
	}
	
	public void detach(LogObservators o) {
		observators.remove(o);
	}
	
	public void notifie(char msg) {
		for(LogObservators o : observators) {
			o.update(msg);
		}
	}
	
	/**
	 * Builds a new Terminal frame
	 */
	public Terminal(){
		createControls();
		this.add(consolePanel);
		this.pack();
		this.setLocationRelativeTo(null);
	}

	/**
	 * Initializes all controls for the TerminalFrame
	 */
	private void createControls() {
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.consolePanel = new JPanel();
		this.consolePanel.setBackground(Color.black);
		createTextArea();
		this.consolePanel.add(jsp);
		
	}
	
	/**
	 * Initializes the terminal text area
	 */
	private void createTextArea() {
		this.commandTA = new JTextArea(24,80);
		this.commandTA.setBackground(Color.black);
		this.commandTA.setForeground(Color.green);
		this.commandTA.setCaretColor(this.commandTA.getForeground());
		this.jsp = new JScrollPane(commandTA);
		this.commandTA.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent event) {
				char key = event.getKeyChar();
				notifie(key);
			}
		});
	}
	
	public void addLogger(LoggerFactory factory) {
		Logger logger = factory.createLogger();
		attach(logger);
	}
	
}


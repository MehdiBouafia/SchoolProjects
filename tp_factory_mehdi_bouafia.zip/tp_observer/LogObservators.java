
public interface LogObservators {

	public void update(char msg);
	
}

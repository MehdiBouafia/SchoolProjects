import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;

/**
 * Simple JFrame with JTextArea that should copy content of the Terminal
 *
 */
public class LogFrame extends JFrame implements Logger {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextArea textArea;
	
	public LogFrame(){
		textArea = new JTextArea();
		textArea.setPreferredSize(new Dimension(500,500));
		this.getContentPane().add(textArea);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
	}

	/**
	 * Appends text to the contents of the text area
	 * @param text the text to log on the frame
	 */
	public void writeText(String text){
		textArea.append(text);
	}
	
	/**
	 * Removes last character of the text area
	 */
	public void removeLast(){
		try {
			textArea.setText(textArea.getText(0, textArea.getText().length()-1));
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(char msg) {
		writeText(Character.toString(msg));
	}
}

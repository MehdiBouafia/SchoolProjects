
public class LogFrameFactory implements LoggerFactory{

	@Override
	public Logger createLogger() {
		LogFrame logFrame = new LogFrame();
		logFrame.setVisible(true);
		return logFrame;
	}

}

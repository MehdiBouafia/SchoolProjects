
public interface Logger extends LogObservators{
	
	public void update(char msg);
	
}

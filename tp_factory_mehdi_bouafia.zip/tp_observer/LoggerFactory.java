
public interface LoggerFactory {

	public Logger createLogger();
	
}

package src.config;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import src.command.AddLoggerCommand;
import src.command.ChangeStrategyLoggerCommand;
import src.command.Command;
import src.command.RemoveLoggerCommand;
import src.model.MessageBuildingStrategy;
import src.model.Terminal;

public class ConfigFrame extends JFrame {
	
	JLabel frameLabel;
	JLabel fileLabel;
	JLabel consoleLabel;
	
	JCheckBox addFileLogger;
	JCheckBox addFrameLogger;
	JCheckBox addConsoleLogger;
	
	JComboBox<MessageBuildingStrategy> selectStrategyFrame;
	JComboBox<MessageBuildingStrategy> selectStrategyFile;
	JComboBox<MessageBuildingStrategy> selectStrategyConsole;
	
	Command addCLCmd = new AddLoggerCommand("ConsoleLogger");
	Command addFileCmd = new AddLoggerCommand("FileLogger");
	Command addFrameCmd = new AddLoggerCommand("LogFrame");
	
	Command rmvCLCmd = new RemoveLoggerCommand("ConsoleLogger");
	Command rmvFileCmd = new RemoveLoggerCommand("FileLogger");
	Command rmvFrameCmd = new RemoveLoggerCommand("LogFrame");
	// TODO define logger command for adding and removing loggers 
	
	public ConfigFrame(MessageBuildingStrategy[] strategies){
		createControls(strategies);
		createListeners();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void createControls(MessageBuildingStrategy[] strategies){
		selectStrategyFrame = new JComboBox<>(strategies);
		selectStrategyFile = new JComboBox<>(strategies);
		selectStrategyConsole = new JComboBox<>(strategies);
		selectStrategyFrame.setEnabled(true);
		selectStrategyFile.setEnabled(true);
		selectStrategyConsole.setEnabled(true);
		
		fileLabel = new JLabel("FileLogger");
		fileLabel.setPreferredSize(new Dimension(200,(int)fileLabel.getPreferredSize().getHeight()));
		frameLabel = new JLabel("LogFrame");
		frameLabel.setPreferredSize(new Dimension(200,(int)frameLabel.getPreferredSize().getHeight()));
		consoleLabel = new JLabel("ConsoleLogger");
		consoleLabel.setPreferredSize(new Dimension(200,(int)consoleLabel.getPreferredSize().getHeight()));
		
		addFileLogger = new JCheckBox();
		addFileLogger.setActionCommand("FileLogger");
		addFrameLogger = new JCheckBox();
		addFrameLogger.setActionCommand("LogFrame");
		addConsoleLogger = new JCheckBox();
		addConsoleLogger.setActionCommand("ConsoleLogger");
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
		mainPanel.add(newConfigurationEntry(fileLabel, addFileLogger, selectStrategyFile));
		mainPanel.add(newConfigurationEntry(frameLabel, addFrameLogger, selectStrategyFrame));
		mainPanel.add(newConfigurationEntry(consoleLabel, addConsoleLogger, selectStrategyConsole));
		this.setTitle("Configuration Logger");
		this.getContentPane().add(mainPanel, BorderLayout.CENTER);
		this.setLocation(Terminal.getInstance().getLocation().x,Terminal.getInstance().getLocation().y-200);
		this.pack();
	}

	private Box newConfigurationEntry(JLabel label, JCheckBox checkBox, JComboBox comboBox) {
		Box box = Box.createHorizontalBox();
		box.add(Box.createHorizontalStrut(50));
		box.add(label);
		box.add(checkBox);
		box.add(Box.createHorizontalStrut(5));
		box.add(comboBox);
		return box;
	}
	
	private void createListeners() {
		selectStrategyFrame.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(addFrameLogger.isSelected() && e.getStateChange()== ItemEvent.SELECTED) {
					// TODO Create and call new ChangeStrategyLoggerCommand
					Command changeStrategy = new ChangeStrategyLoggerCommand((MessageBuildingStrategy) e.getItem(),"LogFrame");
					changeStrategy.execute();
				}
			}
		});
		selectStrategyFile.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				if(addFileLogger.isSelected() && e.getStateChange()== ItemEvent.SELECTED) {
					// TODO Create and call new ChangeStrategyLoggerCommand
					Command changeStrategy = new ChangeStrategyLoggerCommand((MessageBuildingStrategy) e.getItem(),"FileLogger");
					changeStrategy.execute();
				}
			}
			
		});
		selectStrategyConsole.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				if(addConsoleLogger.isSelected() && e.getStateChange()== ItemEvent.SELECTED) {
					// TODO Create and call new ChangeStrategyLoggerCommand
					Command changeStrategy = new ChangeStrategyLoggerCommand((MessageBuildingStrategy) e.getItem(),"ConsoleLogger");
					changeStrategy.execute();
				}
			}
			
		});
		addFileLogger.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				JCheckBox cb = (JCheckBox)e.getSource();
				if(cb.isSelected()){
					// TODO Call command
					addFileCmd.execute();
					selectStrategyFile.setEnabled(true);
				} else {
					// TODO Call command
					rmvFileCmd.execute();
					selectStrategyFile.setEnabled(false);
				}
			}
		});
		addFrameLogger.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				JCheckBox cb = (JCheckBox)e.getSource();
				if(cb.isSelected()){
					// TODO Call command
					addFrameCmd.execute();
					selectStrategyFrame.setEnabled(true);
				} else {
					// TODO Call command
					rmvFrameCmd.execute();
					selectStrategyFrame.setEnabled(false);
				}
			}
		});
		addConsoleLogger.addItemListener(new ItemListener(){
			@Override
			public void itemStateChanged(ItemEvent e) {
				JCheckBox cb = (JCheckBox)e.getSource();
				if(cb.isSelected()){
					// TODO Call command
					addCLCmd.execute();
					selectStrategyConsole.setEnabled(true);
				} else {
					// TODO Call command
					rmvCLCmd.execute();
					selectStrategyConsole.setEnabled(false);
				}
			}
		});
	}
}

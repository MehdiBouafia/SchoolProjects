package src.command;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import src.model.Logger;

public abstract class Command extends AbstractAction{
	
	public abstract Logger execute();
	
	@Override
	public void actionPerformed(ActionEvent e) {
		execute();
	}
}

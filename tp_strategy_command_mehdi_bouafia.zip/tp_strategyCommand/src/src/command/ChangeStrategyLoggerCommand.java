package src.command;

import src.model.Logger;
import src.model.LoggerFactoryImpl;
import src.model.MessageBuildingStrategy;
import src.model.Terminal;

public class ChangeStrategyLoggerCommand extends Command {
	
private String addLoggerName;
//private String rmvLoggerName;
private MessageBuildingStrategy messageStrategy;
	
	public ChangeStrategyLoggerCommand(MessageBuildingStrategy strategy, String addLoggerName) {
		this.addLoggerName = addLoggerName;
		this.messageStrategy = strategy;
	}
	
	@Override
	public Logger execute() {
		// TODO Auto-generated method stub
		Command rmvToChange = new RemoveLoggerCommand(this.addLoggerName);
		rmvToChange.execute();
		/**
		Command rmv1ToChange = new RemoveLoggerCommand("ConsoleLogger");
		rmv1ToChange.execute();
		
		Command rmv2ToChange = new RemoveLoggerCommand("FileLogger");
		rmv2ToChange.execute();
		Command rmv3ToChange = new RemoveLoggerCommand("LogFrame");
		rmv3ToChange.execute();
		*/
		
		Command addToChange = new AddLoggerCommand(this.addLoggerName);
		Logger loggChange = addToChange.execute();
		
		loggChange.setStrategy(this.messageStrategy);
		
		return loggChange;
	}
	
}

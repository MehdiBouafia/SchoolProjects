package src.command;

import src.model.Logger;
import src.model.LoggerFactory;
import src.model.LoggerFactoryImpl;
import src.model.Terminal;

public class AddLoggerCommand extends Command {
	
	private String loggerName;
	
	public AddLoggerCommand(String loggerName) {
		this.loggerName = loggerName;
	}

	@Override
	public Logger execute() {
		LoggerFactoryImpl loggerFactory = new LoggerFactoryImpl();
		LoggerFactoryImpl.getInstance();
		Logger logger = loggerFactory.creeLogger(loggerName);
		Terminal.getInstance().addLogger(logger);
		return logger;
	}
}

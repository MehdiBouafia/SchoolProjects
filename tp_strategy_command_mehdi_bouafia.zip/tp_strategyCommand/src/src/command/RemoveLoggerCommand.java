package src.command;

import src.model.Logger;
import src.model.LoggerFactoryImpl;
import src.model.Terminal;

public class RemoveLoggerCommand extends Command {

	private String loggerName;
	
	public RemoveLoggerCommand(String loggerName) {
		this.loggerName = loggerName;
	}

	@Override
	public Logger execute() {
		Terminal.getInstance().removeLogger(loggerName);
		return null;
	}

}

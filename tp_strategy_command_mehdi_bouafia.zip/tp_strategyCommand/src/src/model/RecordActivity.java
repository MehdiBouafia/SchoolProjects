package src.model;

import src.config.ConfigFrame;

/**
 * Main class for illustrating observers in action
 */
public class RecordActivity {

	public static void main(String[] args) {
		Terminal term = Terminal.getInstance();
		term.setVisible(true);

		MessageBuildingStrategy[] strategies = new MessageBuildingStrategy[4];
		strategies[1] = new RawStrategy();
		strategies[2] = new SilentStrategy();
		strategies[3] = new TimeStampedStrategy();
		// ?DONE? Create configuration strategies
		ConfigFrame cf = new ConfigFrame(strategies);
		cf.setVisible(true);
	}
}

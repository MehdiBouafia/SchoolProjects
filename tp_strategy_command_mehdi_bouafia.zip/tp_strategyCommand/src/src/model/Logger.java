package src.model;
public abstract class Logger implements ObserverESEO{
	public MessageBuildingStrategy strategy;
	
	public Logger(){
		// TODO Default strategy is 'silent'
		setStrategy(new SilentStrategy());
	}
	
	public abstract void log(String message);
	
	public void setStrategy(MessageBuildingStrategy loggingStrategy) {
		strategy = loggingStrategy;
	}

}

package src.model;

public class SilentStrategy implements MessageBuildingStrategy{

	@Override
	public String buildLogMessage(String logEntry) {
		return "*";
	}

}

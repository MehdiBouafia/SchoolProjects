package src.model;

import java.util.Calendar;

public class TimeStampedStrategy implements MessageBuildingStrategy{

	@Override
	public String buildLogMessage(String logEntry) {
		Calendar cal = Calendar.getInstance(); 
		cal.setTimeInMillis(System.currentTimeMillis());
		return (logEntry+cal.get(Calendar.DAY_OF_MONTH)+"/"+(cal.get(Calendar.MONTH)+1)+"/"+cal.get(Calendar.YEAR)+"\n");
	}

}

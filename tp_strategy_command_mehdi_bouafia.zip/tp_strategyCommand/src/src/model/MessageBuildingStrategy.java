package src.model;

public interface MessageBuildingStrategy {
	
	public String buildLogMessage(String logEntry);

}

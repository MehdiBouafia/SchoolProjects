package src.model;

public class RawStrategy implements MessageBuildingStrategy{

	@Override
	public String buildLogMessage(String logEntry) {
		return logEntry;
	}

}
